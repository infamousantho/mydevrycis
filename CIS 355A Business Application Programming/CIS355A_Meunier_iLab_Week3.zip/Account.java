import javax.swing.JOptionPane;

/*********************************************
Program Name: Account.java
Programmer's Name: Anthony Meunier
Program Description: Parent class that creates and 
instantiates basic attributes, methods, and 
constructor for a bank account and processes 
transactions such as deposits and withdrawals and 
allows user to enter information about the account.
 ********************************************/

public class Account {
	
	//Attributes
	public String AccountName;
	public int AccountId;
	public double Balance;
	
	//Method to accept single double parameter containing deposit amount
	public void ProcessDeposit(double depositAmount){
		Balance += depositAmount;
	}
	
	//Method to accept single double parameter containing withdrawal amount
	public void ProcessWithdrawal(double withdrawalAmount){
		Balance -= withdrawalAmount;
	}
	
	//Method coded as double with empty body
	public double CalcInterest(){
		return 0;		
	}
	
	//Constructor to prompt the user and accept input for Account Name, Account ID, and initial balance
	public Account(){
		String AcctName = JOptionPane.showInputDialog("Enter Account Name");
		int AcctId = Integer.parseInt(JOptionPane.showInputDialog("Enter Account ID"));
		double balance = Double.parseDouble(JOptionPane.showInputDialog("Enter Initial Account Balance"));
		AccountName = AcctName;
		AccountId = AcctId;
		Balance = balance;
	}
	

} //End class