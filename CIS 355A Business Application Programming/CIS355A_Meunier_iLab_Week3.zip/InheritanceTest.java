import javax.swing.JOptionPane;

/*********************************************
Program Name: InheritanceTest.java
Programmer's Name: Anthony Meunier
Program Description: Main class that will prompt 
user for bank name and routing number and creates 
different account objects, then processes a deposit 
and a withdrawal as well as interest. 
Takes information and generates a report.
 ********************************************/

public class InheritanceTest {

	//Main method to collect input, create objects and process calculations
	public static void main(String[] args) {
		
		//Prompt user for information
		String BankName = JOptionPane.showInputDialog("Enter Bank Name");
		int RoutingNumber = Integer.parseInt(JOptionPane.showInputDialog("Enter Routing Number"));
		
		//Create account objects
		CheckingAcct Account1 = new CheckingAcct();
		SavingsAcct Account2 = new SavingsAcct();
		
		//Process deposits
		Account1.ProcessDeposit(800);
		Account2.ProcessDeposit(250);
		
		//Process withdrawals
		Account1.ProcessWithdrawal(400);
		Account2.ProcessWithdrawal(300);
		
		//Calculate interest
		Account1.CalcInterest();
		Account2.CalcInterest();
		
		//Generate report and show message/output
		String output = "Bank Name: "+BankName + " Routing Number: " + RoutingNumber;
		output+= "\nAccount Name: " + Account1.AccountName + " Account ID: " + Account1.AccountId + " Balance: " + Account1.CalcInterest();
		output+= "\nAccount Name: " + Account2.AccountName + " Account ID: " + Account2.AccountId + " Balance: " + Account2.CalcInterest();
		
		JOptionPane.showMessageDialog(null, output);
		
	}

	
} //End class
