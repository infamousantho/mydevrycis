/*********************************************
Program Name: SavingsAcct.java
Programmer's Name: Anthony Meunier
Program Description: Child class that is derived from 
Account class. Will inherit Account class attributes, 
methods, and constructor and will also perform 
specific function related to "savings" account type.
 ********************************************/

public class SavingsAcct extends Account {

	//Method to apply interest rate
	public double CalcInterest(){
		if(super.Balance >= 5000)
		{
			return super.Balance + (0.04*super.Balance);
		}
		if(super.Balance >= 3000)
		{
			return super.Balance + (0.03*super.Balance);
		}
		return super.Balance + (0.02*super.Balance);		
	}
	
	
} //End class
