import javax.swing.JOptionPane;

/*********************************************
Program Name: CheckingAcct.java
Programmer's Name: Anthony Meunier
Program Description: Child class that is derived from 
Account class. Will inherit Account class attributes, 
methods, and constructor and will also perform 
specific function related to "checking" account type.
 ********************************************/

public class CheckingAcct extends Account {

	//Attributes
	public double overDraftFee;
		
	//Method to apply interest rate
	public double CalcInterest(){
		if((super.Balance-overDraftFee) >= 3000)
		{
			return (super.Balance-overDraftFee) + (0.01*(super.Balance-overDraftFee));
		}
		return 0;		
	}
	
	//Constructor to prompt the user for the overDraftFee
	public CheckingAcct(){
		super();
		overDraftFee= Double.parseDouble(JOptionPane.showInputDialog("Enter Overdraft Fees"));
	}

	
} //End class