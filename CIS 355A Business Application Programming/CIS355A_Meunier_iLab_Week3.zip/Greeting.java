import java.applet.*;
import java.awt.*;
import java.awt.event.*;

/*********************************************
Program Name: Greeting.java
Programmer's Name: Anthony Meunier
Program Description: Creates an applet program 
that collects and displays information using 
defined settings and implements actionPerformed method
to provide event handling for button click.
 ********************************************/

public class Greeting extends Applet implements ActionListener {
	
	//Create and initialize required objects
	Label inputLabel = new Label("Please enter your name:");
	TextField inputText = new TextField(20);
	Button GreetButton = new Button("GREET");
	Label outputLabel = new Label("Result goes here");
	
	//Method to initialize what we need for applet
	public void init() {
		
		setSize(500, 500);
		setBackground(Color.yellow);
		
		add(inputLabel);
		add(inputText);
		add(GreetButton);
		add(outputLabel);
		
		GreetButton.addActionListener(this);		    
	}
	
	//Method to provide event handling for button
	public void actionPerformed(ActionEvent e) {
		String text = inputText.getText();
		outputLabel.setText("Hello "+ text);
	}
	

} //End class
