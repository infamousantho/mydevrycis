/***********************************************************************
Program Name: Snowman.java
Programmer's Name: Anthony Meunier
Program Description: This class draws and displays a snowman.
***********************************************************************/

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Snowman extends JPanel{
	
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	private JFrame frame = new JFrame("Snowman"); //Frame object for the display
	
	public Snowman(){
		frame.add(this);
  	  	frame.setSize(500, 500);
  	  	frame.setResizable(false);
		frame.setVisible(true);
	}
	
	/**
	 * paintComponent method 
	 * @param  g Graphics object
	 */
	
	public void paintComponent(Graphics g)
    {
          super.paintComponent(g); //Base class method clears background
       
          g.setColor(Color.blue);
          g.fillRect(0, 0, getWidth(), getHeight());
          g.setColor(Color.white);
          g.fillOval(100,0, 100, 100);
          g.fillOval(50,95, 200, 200);
          g.fillOval(50,250, 200, 200);
          
          g.translate(125, 10);
         
          g.translate(0, 70);
          g.setColor(Color.BLUE);
          g.fillRect(0, -40, 10, 10); 
          g.translate(40, 0);
          g.setColor(Color.BLUE);
          g.fillRect(0, -40, 10, 10); 
          g.translate(-20, 20);
          g.setColor(Color.GREEN);
          g.fillOval(0,-40, 10, 10);
          g.setColor(Color.red);
          g.translate(-20, -20);
          g.drawArc(0, -40, 50,50, 240, 70);
          g.translate(20, 100);
          g.setColor(Color.green);
          g.fillOval(0,-20, 15, 15);
          g.translate(0, 30);
          g.setColor(Color.black);
          g.fillOval(0,-20, 15, 15);
          g.translate(0, 30);
          g.setColor(Color.red);
          g.fillOval(0,-20, 15, 15);
          g.translate(100, -100);
          int fontSize = 20;

          g.setFont(new Font("Arial", Font.PLAIN, fontSize));
           
          g.setColor(Color.white);
          
          g.drawString("My Snowman!", 75, 100);
        
         
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unused")
		Snowman s = new Snowman();
	}

}