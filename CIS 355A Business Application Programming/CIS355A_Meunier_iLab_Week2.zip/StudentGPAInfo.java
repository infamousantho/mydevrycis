import java.text.DecimalFormat;

/*********************************************
Program Name: StudentGPAInfo.java
Programmer's Name: Anthony Meunier
Program Description: Calculate student GPA.
 ********************************************/

public class StudentGPAInfo {

	//Declare instance variables
	private double gpa;
	private int totalGradePoints;
	private int numberOfClasses;
	private String studentName;
	
	//Parameterized constructor
	public StudentGPAInfo(String name, int totalPoints, int noOfClasses){
		gpa = 0;
		totalGradePoints = totalPoints;
		studentName = name;
		numberOfClasses = noOfClasses;
	}
	
	//Default constructor
	public StudentGPAInfo(){
		gpa = 0;
		totalGradePoints = 0;
		numberOfClasses= 0;
		studentName = "";
	}
	
	//Instance method to calculate GPA
	public void CalculateGPA(){
		gpa = totalGradePoints/(numberOfClasses*1.0);
	}
	
	//Set method to assign values to variables
	public void Set(String name, int totalPoints, int noOfClasses){
		totalGradePoints = totalPoints;
		studentName = name;
		numberOfClasses = noOfClasses;
	}
	
	//Method to display attributes of StudentGPAInfo object
	public void displayStudent(){
		DecimalFormat decFormat = new DecimalFormat("#.00");
		System.out.println("************************************");
		System.out.println("Student Name: " + studentName);
		System.out.println("Total Grade Points: " + totalGradePoints);
		System.out.println("Number of Classes: " + numberOfClasses);
		System.out.println("GPA: " + decFormat.format(gpa));
		System.out.println("************************************");
		System.out.println();
	}
	
} //End class
