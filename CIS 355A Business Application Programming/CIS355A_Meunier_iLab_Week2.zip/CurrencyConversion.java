import java.text.DecimalFormat;
import javax.swing.JOptionPane;

/*********************************************
Program Name: CurrencyConversion.java
Programmer's Name: Anthony Meunier
Program Description: Converts money between currencies using JOptionPane GUI.
 ********************************************/

public class CurrencyConversion {

	//Method to gather input and display output
	public static void main(String[] args) {
		
		//Objects to gather input
		String SourceCurrency = JOptionPane.showInputDialog("Enter Currency Code of the Input Amount");
		double Amount = Double.parseDouble(JOptionPane.showInputDialog("Enter Input Amount to be converted"));
		String TargetCurrency = JOptionPane.showInputDialog("Enter Currency Code for the currency you are converting to.");
		double ConvertedAmount = ConvertCurrency(Amount,SourceCurrency,TargetCurrency);
		
		DecimalFormat df = new DecimalFormat("#,###.00");
		
		//Display output
		if(ConvertedAmount == -1){
			JOptionPane.showMessageDialog(null, "Unable to calculate conversion. Please enter the valid inputs");			
		}
		else{
		JOptionPane.showMessageDialog(null, SourceCurrency + " Converted " + TargetCurrency + " Amount: "+ df.format(ConvertedAmount));
		}
	}
	
	//Method to perform currency conversions
	public static double ConvertCurrency(double Amount, String SourceCurrency, String TargetCurrency) {
		
		
		//Convert from USD
		double convertedAmount = -1;
		SourceCurrency = SourceCurrency.trim().toUpperCase();
		TargetCurrency = TargetCurrency.trim().toUpperCase();
			switch(SourceCurrency){
		case "USD":
			if(TargetCurrency.equals("POUND")){
				convertedAmount = Amount * 0.64;
			}
			else if(TargetCurrency.equals("JPY")){
				convertedAmount = Amount * 124.15;
			}			
			break;
			
		//Convert from POUND	
		case "POUND":
			if(TargetCurrency.equals("USD")){
				convertedAmount = Amount / 0.64;
			}
			else if(TargetCurrency.equals("JPY")){
				convertedAmount = Amount * 193.58;
			}
			break;
			
		//Convert from JPY	
		case "JPY":
			if(TargetCurrency.equals("USD")){
				convertedAmount = Amount / 124.15;
			}
			else if(TargetCurrency.equals("POUND")){
				convertedAmount = Amount / 193.58;
			}
			break;
		}
			
		return convertedAmount;
		
	}
	
} //End class
