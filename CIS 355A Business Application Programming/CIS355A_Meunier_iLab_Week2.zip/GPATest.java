/*********************************************
Program Name: GPATest.java
Programmer's Name: Anthony Meunier
Program Description: Create student objects to
pass values and instantiate StudentGPAInfo() 
class objects/constructors.
 ********************************************/

public class GPATest {
	
	public static void main(String[] args){
		
		//Create object using parameterized constructor to pass values
		StudentGPAInfo student1 = new StudentGPAInfo("Kobe", 14, 4);
		
		//Create object using default constructor
		StudentGPAInfo student2 = new StudentGPAInfo();
		
		//Use set method to assign values to student2 object
		student2.Set("Shaq", 12, 3);
		
		//Use calculateGPA() method on both objects
		student1.CalculateGPA();
		student2.CalculateGPA();
		
		//Invoke displayStudent() method on each object
		student1.displayStudent();
		student2.displayStudent();
	}

} //End class
