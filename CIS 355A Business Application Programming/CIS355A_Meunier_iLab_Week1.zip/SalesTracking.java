import java.text.DecimalFormat;
import java.util.Scanner;

//Program Name: SalesTracking.java
//Programmer's Name: Anthony Meunier
/*Program Description: Track monthly sales as well as compute average 
 * yearly sales, total sales for year, and which month had the 
 * highest sales and which month had lowest sales.
 */

public class SalesTracking 
{
	
	//Set up scanner for input
    public static final Scanner scan = new Scanner(System.in);

	//Main method to declare variables and make calls
	public static void main(String[] args)
	{
		
		//Declare variables
		double totalSales;
		double averageSales;
		int highestMonth;
		int lowestMonth;
		
		//Receive monthly sales from user
		getSales();
		
		//Receive total yearly sales
		totalSales = computeTotalSales(monthlySales);
		
		//Receive average monthly sales
		averageSales = computeAverageSales(monthlySales);
		
		//Receive month with highest sales
		highestMonth = computeHighestMonth(monthlySales);
		
		//Receive month with lowest sales
		lowestMonth = computeLowestMonth(monthlySales);
		
		//Display output
		displaySaleInfo(totalSales, averageSales, highestMonth, monthlySales[highestMonth], lowestMonth, monthlySales[lowestMonth]);

	} //End main
	
	
	//Create array with months
	public static final String monthArray[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
	
	
	//Create array to store monthly sales
	public static final double monthlySales[] = new double[12];
	
	
	//Method to receive input from user
	public static void getSales()
	{
		//Prompt user to enter sales for each month
		for (int i = 0; i < monthlySales.length; i = i + 1)
		{
			System.out.print("Enter " + monthArray[i] + " Sales: ");
		
			//Validate input
			while (!scan.hasNextDouble())
			{
				System.out.print("You must enter a valid sales figure for " + monthArray[i] + "! Try again: ");
				scan.next();
			}
		
			//Save in monthly sales array
			monthlySales[i] = scan.nextDouble();
		}
	} //End method
	
	
	//Method to calculate total sales
	public static double computeTotalSales(double monthlySales[])
	{
		double totalSale = 0;
		
		//Calculate total sales
		for (int i = 0; i < monthlySales.length; i = i + 1)
		{
			totalSale += monthlySales[i];
		}
		
		//Return total sales
		return totalSale;
		
	} //End method
	
	
	//Method to calculate average sales
	public static double computeAverageSales(double monthlySales[])
	{
		double totalSale = 0;
		double avgSale;
		
		//Calculate total sales
		for (int i = 0; i < monthlySales.length; i = i + 1)
		{
			totalSale += monthlySales[i];
		}
		
		//Calculate average sales
		avgSale = totalSale / 12;
		
		//Return average sales
		return avgSale;
		
	} //End method
	
	
	//Method to find highest value from monthlySales array
	public static int computeHighestMonth(double monthlySales[])
	{
		double highestSales = monthlySales[0]; //Store in first element of monthlySales array
		int highestMonth = 0; //Store highest month
		
		//Find the highest month
		for (int i = 0; i < monthlySales.length; i = i + 1)
		{
			if (highestSales < monthlySales[i])
			{
				highestSales = monthlySales[i];
				highestMonth = i;
			}
		}
		
		//Return highest month
		return highestMonth;
		
	} //End method
	
	
	//Method to find lowest value from monthlySales array
	public static int computeLowestMonth(double monthlySales[])
	{
		double lowestSales = monthlySales[0]; //Store in first element of monthlySales array
		int lowestMonth = 0; //Store lowest month
		
		//Find the lowest month
		for (int i = 0; i < monthlySales.length; i = i + 1)
		{
			if (lowestSales > monthlySales[i])
			{
				lowestSales = monthlySales[i];
				lowestMonth = i;
			}
		}
		
		//Return lowest month
		return lowestMonth;
		
	} //End method
	
	
	//Method to display total yearly sales, average monthly sales, the month with highest sales, and the month with lowest sales
	public static void displaySaleInfo(double totalSales, double averageSales, int highestMonth, double highestSales, int lowestMonth, double lowestSales)
	{
		//Round the sales to two decimal places
		DecimalFormat decFormat = new DecimalFormat("#.##");
		
		System.out.println(""); //print blank line
		
		//Display results
		System.out.println("Total Sales: " + decFormat.format(totalSales) + "\nAverage Sales: " + decFormat.format(averageSales) + "\nHighest Month: " + monthArray[highestMonth] + " \nHighest Sales: " + decFormat.format(highestSales) + " \nLowest Month: " + monthArray[lowestMonth] + " \nLowest Sales: " + decFormat.format(lowestSales));
	} //End method
	

} //End class
