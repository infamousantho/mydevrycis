﻿'Import mySQL.Data from references and load data
Imports MySql.Data.MySqlClient

Public Class Form4
    'Declare connection
    Dim MysqlConn As MySqlConnection
    Dim COMMAND As MySqlCommand

    'Fill DataGridView with MySQL table values when using "Refresh" button-click
    Private Sub Load_Table_Btn_Click(sender As Object, e As EventArgs) Handles Load_Table_Btn.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"
        'Connect DataGridView with database table
        'Get data with adapter
        Dim SDA As New MySqlDataAdapter
        'Bind data from adapter to DataGridView
        Dim dbDataSet As New DataTable
        Dim bSource As New BindingSource
        Try
            'Open connection to database
            MysqlConn.Open()
            'Declare query
            Dim Query As String
            'Query that will pull from database and return to DataGridView
            Query = "select * from payroll.employeeproject"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            SDA.SelectCommand = COMMAND
            'Take values from query and fill to DataSet
            SDA.Fill(dbDataSet)
            'Bind DataSet to DataGridView
            bSource.DataSource = dbDataSet
            DataGridView1.DataSource = bSource
            SDA.Update(dbDataSet)

            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    'Automatically load DataGridView upon page creation/load (same as above, just automatic and does not require refresh button press)
    Private Sub load_table()
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"
        Dim SDA As New MySqlDataAdapter
        Dim dbDataSet As New DataTable
        Dim bSource As New BindingSource
        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "select * from payroll.employeeproject"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            SDA.SelectCommand = COMMAND
            SDA.Fill(dbDataSet)
            bSource.DataSource = dbDataSet
            DataGridView1.DataSource = bSource
            SDA.Update(dbDataSet)

            MysqlConn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_table()
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Form6.Show()
        Me.Hide()
    End Sub

    'Add data on button click
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"
        Dim READER As MySqlDataReader


        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "insert into payroll.employeeproject (EmployeeNumber, ProjectNumber, Date, HoursWorked) values ('" & TextBox_EmployeeNumber.Text & "', '" & TextBox_ProjectNumber.Text & "', '" & TextBox_Date.Text & "', '" & TextBox_HoursWorked.Text & "')"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader

            MessageBox.Show("Data Added")
            MysqlConn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    'Update data on button click
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"
        Dim READER As MySqlDataReader


        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "update payroll.employeeproject set EmployeeNumber='" & TextBox_EmployeeNumber.Text & "', ProjectNumber='" & TextBox_ProjectNumber.Text & "', Date='" & TextBox_Date.Text & "', HoursWorked='" & TextBox_HoursWorked.Text & "' where EmployeeNumber='" & TextBox_EmployeeNumber.Text & "'"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader

            MessageBox.Show("Data Modified")
            MysqlConn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub

    'Delete data on button click
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"
        Dim READER As MySqlDataReader


        Try
            MysqlConn.Open()
            Dim Query As String
            Query = "Delete from payroll.employeeproject where EmployeeNumber='" & TextBox_EmployeeNumber.Text & "'"
            COMMAND = New MySqlCommand(Query, MysqlConn)
            READER = COMMAND.ExecuteReader

            MessageBox.Show("Data Deleted")
            MysqlConn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            MysqlConn.Dispose()
        End Try
    End Sub
End Class