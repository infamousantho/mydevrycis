﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Dim MysqlConn As New MySqlConnection

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"


        MysqlConn.Open()


        If MysqlConn.State = ConnectionState.Open Then
            MsgBox("You are now connected!")
            Form6.Show()
            Me.Hide()
        Else
            MessageBox.Show("Failed to connect")
        End If

        MysqlConn.Close()



    End Sub

End Class
