﻿'Import mySQL.Data from references and load data
Imports MySql.Data.MySqlClient

Public Class Form1
    'Declare connection
    Dim MysqlConn As New MySqlConnection

    'Have button-click open connection to designated server
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MysqlConn = New MySqlConnection
        MysqlConn.ConnectionString = "server=localhost; userid=root; password=password1; database=payroll;"

        'Open connection to database
        MysqlConn.Open()

        'Display successful connection or error message if failed to connect
        If MysqlConn.State = ConnectionState.Open Then
            MsgBox("You are now connected!")
            Form6.Show()
            Me.Hide()
        Else
            MessageBox.Show("Failed to connect")
        End If

        MysqlConn.Close()
    End Sub

End Class
