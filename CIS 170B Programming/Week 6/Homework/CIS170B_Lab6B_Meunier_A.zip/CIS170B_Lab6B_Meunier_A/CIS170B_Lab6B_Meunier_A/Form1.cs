﻿// ---------------------------------------------------------------
// Programming Assignment: LAB6B
// Developer: Anthony Meunier
// Date Written: 8/17/2014
// Purpose:	Number Guessing Game
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS170B_Lab6B_Meunier_A
{
    public partial class Form1 : Form
    {
        //declare and initialize global variables
        Random r = new Random();
        int target;
        int numGuesses = 0;

        public Form1()
        {
            //randomly pick a target number between 0 and 100
            InitializeComponent();
            target = r.Next(0, 100);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //evaluate button click function
        private void btnEval_Click(object sender, EventArgs e)
        {
            int num1;
           //check to make sure textbox is not empty
            if (!String.IsNullOrEmpty(txtNumberEntered.Text))
            {  
                //counter for number of guesses
                numGuesses++;
                //pull guess from the textbox 
                num1 = Convert.ToInt32(txtNumberEntered.Text);

                //if guess is less than random computer target
                if (num1 < target)
                {
                    //make evaluate button invisible
                    btnEval.Visible = false;
                    //change the label message
                    lblMessage.Text = "Too Low!!";
                    //make the label message visible
                    lblMessage.Visible = true;
                    //change background color
                    this.BackColor = Color.LightSeaGreen;
                    //make try again button visible
                    btnTryAgain.Visible = true;
                } 

                //if guess is greater than random computer target
                else if (num1 > target)
                {
                    //make the evaluate button invisible
                    btnEval.Visible = false;
                    //change the label message
                    lblMessage.Text = "Too high!!";
                    //make the label message visible
                    lblMessage.Visible = true;
                    //change the background color
                    this.BackColor = Color.SlateBlue;
                    //make the try again button visible
                    btnTryAgain.Visible = true;
                }

                //display message indicating user guessed correctly and display the number of guesses it took
                else  
                    MessageBox.Show("You are right!! It took you " + numGuesses + " guesses.");
                }
            }

        //try again button click function
        private void btnTryAgain_Click(object sender, EventArgs e)
        {
            //change the background color to original since we are trying guess again
            this.BackColor = Color.Gainsboro;
            //make the try again button invisible
            btnTryAgain.Visible = false;
            //clear the guess textbox
            txtNumberEntered.Clear();
            //make the label message invisible
            lblMessage.Visible = false;
            //make the evaluate button visible
            btnEval.Visible = true;
        }    

        }

    }
