﻿namespace CIS170B_Lab6B_Meunier_A
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnterGuess = new System.Windows.Forms.Label();
            this.txtNumberEntered = new System.Windows.Forms.TextBox();
            this.btnEval = new System.Windows.Forms.Button();
            this.btnTryAgain = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblEnterGuess
            // 
            this.lblEnterGuess.AutoSize = true;
            this.lblEnterGuess.Location = new System.Drawing.Point(77, 53);
            this.lblEnterGuess.Name = "lblEnterGuess";
            this.lblEnterGuess.Size = new System.Drawing.Size(111, 13);
            this.lblEnterGuess.TabIndex = 0;
            this.lblEnterGuess.Text = "Enter a guess 0 - 100:";
            // 
            // txtNumberEntered
            // 
            this.txtNumberEntered.Location = new System.Drawing.Point(203, 50);
            this.txtNumberEntered.Name = "txtNumberEntered";
            this.txtNumberEntered.Size = new System.Drawing.Size(100, 20);
            this.txtNumberEntered.TabIndex = 1;
            // 
            // btnEval
            // 
            this.btnEval.Location = new System.Drawing.Point(114, 163);
            this.btnEval.Name = "btnEval";
            this.btnEval.Size = new System.Drawing.Size(171, 71);
            this.btnEval.TabIndex = 2;
            this.btnEval.Text = "Press to EVALUATE your guess!";
            this.btnEval.UseVisualStyleBackColor = true;
            this.btnEval.Click += new System.EventHandler(this.btnEval_Click);
            // 
            // btnTryAgain
            // 
            this.btnTryAgain.Location = new System.Drawing.Point(114, 271);
            this.btnTryAgain.Name = "btnTryAgain";
            this.btnTryAgain.Size = new System.Drawing.Size(171, 66);
            this.btnTryAgain.TabIndex = 3;
            this.btnTryAgain.Text = "Press to CLEAR your guess and TRY AGAIN!";
            this.btnTryAgain.UseVisualStyleBackColor = true;
            this.btnTryAgain.Visible = false;
            this.btnTryAgain.Click += new System.EventHandler(this.btnTryAgain_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(179, 116);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(35, 13);
            this.lblMessage.TabIndex = 4;
            this.lblMessage.Text = "label1";
            this.lblMessage.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(422, 365);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnTryAgain);
            this.Controls.Add(this.btnEval);
            this.Controls.Add(this.txtNumberEntered);
            this.Controls.Add(this.lblEnterGuess);
            this.Name = "Form1";
            this.Text = "Guessing Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnterGuess;
        private System.Windows.Forms.TextBox txtNumberEntered;
        private System.Windows.Forms.Button btnEval;
        private System.Windows.Forms.Button btnTryAgain;
        private System.Windows.Forms.Label lblMessage;
    }
}

