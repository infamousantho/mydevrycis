﻿// ---------------------------------------------------------------
// Programming Assignment: LAB6A
// Developer: Anthony Meunier
// Date Written: 8/16/2014
// Purpose:	Password Program
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS170B_Lab6A_Meunier_A
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        //next button function
        private void btnNext_Click(object sender, EventArgs e)
        {
            //declare variables
            string password1, password2;
            password1 = (txtPassword1.Text);
            password2 = (txtPassword2.Text);

            //verify first password textbox is not blank
            if (!String.IsNullOrEmpty(txtPassword1.Text))
            {
                //make visible second password textbox etc
                lblPassword2.Visible = true;
                txtPassword2.Visible = true;
                btnContinue.Visible = true;
                lblConfirm.Visible = true;
                
            }
                //display error if textbox is empty
            else
            {
                MessageBox.Show("You must enter a password!");

            }
            
        }

        //continue button function
        private void btnContinue_Click(object sender, EventArgs e)
        {
            //declare variables
            string password1, password2;
            password1 = (txtPassword1.Text);
            password2 = (txtPassword2.Text);

            //verify first password textbox is not blank
            if (!String.IsNullOrEmpty(txtPassword1.Text))
            //check if first password textbox equals second password textbox
                if (password1 == password2)
                {
                    MessageBox.Show("Passwords are the same.");
                }
                    //check if passwords do not equal each other
                else
                {
                    MessageBox.Show("Passwords are different.");
                }   
//display error if textbox is empty
            else
            {
                MessageBox.Show("You must enter a password!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
