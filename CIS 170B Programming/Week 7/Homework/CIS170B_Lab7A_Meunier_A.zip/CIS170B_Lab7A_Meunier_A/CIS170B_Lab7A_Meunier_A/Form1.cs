﻿// ---------------------------------------------------------------
// Programming Assignment: LAB7A
// Developer: Anthony Meunier
// Date Written: 8/23/2014
// Purpose:	Contact Manager
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CIS170B_Lab7A_Meunier_A
{
    public partial class Form1 : Form
    {
        public StreamWriter outFile;
        public StreamReader inFile;

        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            try
            {
                outFile = new StreamWriter("cis170Lab7.txt", true);
                outFile.WriteLine(txtName.Text);
                outFile.WriteLine(txtEmail.Text);
                outFile.WriteLine();
                outFile.Close();
                txtEmail.Text = "";
                txtName.Text = "";
            }
            catch (System.IO.IOException exc)
            {
                MessageBox.Show(exc.Message);
            }

            //display data from file
            lstContacts.Items.Clear();
            string inval;
            try
            {
                inFile = new StreamReader("cis170Lab7.txt");
                while ((inval = inFile.ReadLine()) != null)
                {
                    lstContacts.Items.Add(inval);
                }
                inFile.Close();
            }
            catch (System.IO.IOException exc)
            {
                MessageBox.Show(exc.Message);
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            outFile.Close();
            inFile.Close();
        }
    }
}
