﻿// ---------------------------------------------------------------
// Programming Assignment: LAB4A
// Developer: Anthony Meunier
// Date Written: 8/3/2014
// Purpose:	Phone Dialing Program
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS170B_Lab4A
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            char d1 = 'a', d2 = 'a', d3 = 'a', d4 = 'a', d5 = 'a', d6 = 'a', d7 = 'a', d8 = 'a';
            int checkValue = 0;
            

            //call ProcessInput
            do
            {
                checkValue = ProcessInput(ref d1, ref d2, ref d3, ref d4, ref d5, ref d6, ref d7, ref d8);



                switch (checkValue)
                {
                    case -1:
                        Console.WriteLine("Invalid input, please try again.");
                        break;
                    default:
                        Console.WriteLine("Valid phone number: " + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8);
                        break;
                }

            } while (true);

        }

        //get input
        public static void GetInput(ref char d1, ref char d2, ref char d3, ref char d4, ref char d5, ref char d6, ref char d7, ref char d8)
        {

            Console.Write("Please enter a phone number: ");
            d1 = Convert.ToChar(Console.Read());
            d2 = Convert.ToChar(Console.Read());
            d3 = Convert.ToChar(Console.Read());
            d4 = Convert.ToChar(Console.Read());
            d5 = Convert.ToChar(Console.Read());
            d6 = Convert.ToChar(Console.Read());
            d7 = Convert.ToChar(Console.Read());
            d8 = Convert.ToChar(Console.Read());

            Console.ReadLine();
        }

        //process input
        public static int ProcessInput(ref char d1, ref char d2, ref char d3, ref char d4, ref char d5, ref char d6, ref char d7, ref char d8)
        {
            
            if (d1 == '0')
            {
                return -1;
            }
            if (d1 == '5' && d2 == '5' && d3 == '5')
            {
                return -1;
            }

            if (ToDigit(ref d1) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d2) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d3) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d5) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d6) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d7) == -1)
            {
                return -1;
            }
            if (ToDigit(ref d8) == -1)
            {
                return -1;
            }
            return 0;
        }


        public static int ToDigit(ref char d)
        {
            d = Char.ToUpper(d);
            switch (d)
            {
                case '0':
                    d = '0';
                    break;
                case '1':
                    d = '1';
                    break;
                case 'A': case 'B': case 'C': case '2':
                    d = '2';
                    break;
                case 'D': case 'E': case 'F': case '3':
                    d = '3';
                    break;
                case 'G': case 'H': case 'I': case '4':
                    d = '4';
                    break;
                case 'J': case 'K': case 'L': case '5':
                    d = '5';
                    break;
                case 'M': case 'N': case 'O': case '6':
                    d = '6';
                    break;
                case 'P': case 'Q': case 'R': case 'S': case '7':
                    d = '7';
                    break;
                case 'T': case 'U': case 'V': case '8':
                    d = '8';
                    break;
                case 'W': case 'X': case 'Y': case 'Z': case '9':
                    d = '9';
                    break;
                default:
                    return -1;
            }
        }



    }
}

