﻿// ---------------------------------------------------------------
// Programming Assignment: LAB5B
// Developer: Anthony Meunier
// Date Written: 8/9/2014
// Purpose:	Alphabetical Order
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CIS170B_Lab5B
{
    class Program
    {
        //main function
        static void Main(string[] args)
        {
            //instantiate arraylist object
            ArrayList nameArray = new ArrayList();

            //load user input from function
            GetNames(nameArray);

            //display count of last names
            Console.WriteLine("\nLast names entered: " + nameArray.Count);

            //sort arraylist
            nameArray.Sort();
            Console.WriteLine("\nNames in Ascending Order\n");
            //loop to display names
            for (int i = 0; i < nameArray.Count; i++)
            {
                Console.WriteLine(nameArray[i]);
            }
            //reverse the order of the arraylist
            nameArray.Reverse();
            Console.WriteLine("\nNames in Descending Order\n");
            //loop to display names
            for (int i = 0; i < nameArray.Count; i++)
            {
                Console.WriteLine(nameArray[i]);
            }

            Console.ReadLine();
            
        }

        //get user input until they want to quit
        static void GetNames(ArrayList nameArray)
        {
            do
            {
                Console.Write("Enter a last name: ");
                nameArray.Add(Console.ReadLine());

                Console.Write("Keep going? (Y/N): ");
            }
            while (Console.ReadLine().ToUpper() == "Y");

        }



    }
}
