﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Week_5_1_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] scores;
            int numberOfScores;

            Console.WriteLine("How many scores?");
            numberOfScores = Convert.ToInt32(Console.ReadLine());

            scores = new int[numberOfScores];  

            //int[] scores = new int[5];

            //numberOfScores = scores.GetUpperBound(0); // or scores.Length

            for (int index = 0; index < numberOfScores; index++)
            {
                Console.WriteLine("Please enter score {0}: ", index + 1);
                scores[index] = Convert.ToInt32(Console.ReadLine());
            }

            //for (int index = 0; index < scores.Length; index++)
            //{
            //    Console.WriteLine("Please enter score {0}: ", index + 1);
            //    scores[index] = Convert.ToInt32(Console.ReadLine());
            //}

            //for (int index = 0; index < 5; index++)
            //{
            //    Console.WriteLine("Please enter score {0}: ", index + 1);
            //    scores[index] = Convert.ToInt32(Console.ReadLine());
            //}
            
            //Array.Sort(scores);

            //Console.WriteLine(scores.Min());
            //Console.WriteLine(scores.Max());
            //Console.WriteLine(scores.Sum());

            //scores[5] = 100; // this exceeded the array



            Console.ReadLine();
        }
    }
}
