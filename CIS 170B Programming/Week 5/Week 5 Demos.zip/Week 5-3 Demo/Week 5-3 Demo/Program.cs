﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Collections; // we need this for collections

namespace Week_5_3_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            string response;
            int score;

            ArrayList scores = new ArrayList();

            do
            {
                Console.WriteLine("Score:");
                score = Convert.ToInt32(Console.ReadLine());

                scores.Add(score);
            
                Console.WriteLine("Continue?");
                response = Console.ReadLine();
            }
            while (response.ToLower() == "y");

            scores.Sort();
            scores.Reverse();
                        

            Console.ReadLine();  
        }
    }
}
