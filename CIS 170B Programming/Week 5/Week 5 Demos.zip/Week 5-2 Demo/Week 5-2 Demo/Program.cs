﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Week_5_2_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] scores; // declare array
            int numberOfScores;

            Console.WriteLine("How many scores?");
            numberOfScores = Convert.ToInt32(Console.ReadLine());

            // create the array
            scores = new int[numberOfScores];

            LoadScores(scores);
            DisplayScores(scores);

            Console.ReadLine();
        }

        static void DisplayScores(int[] scores)
        {
            int numberOfScores = scores.Length;

            for (int index = 0; index < numberOfScores; index++)
            {
                Console.WriteLine("Score {0}: {1} ", index + 1, scores[index]);                
            }
        }

        static void LoadScores(int[] scores)
        {
            int numberOfScores = scores.Length;

            for (int index = 0; index < numberOfScores; index++)
            {
                Console.WriteLine("Please enter score {0}: ", index + 1);
                scores[index] = Convert.ToInt32(Console.ReadLine());
            }
        }

    }
}
