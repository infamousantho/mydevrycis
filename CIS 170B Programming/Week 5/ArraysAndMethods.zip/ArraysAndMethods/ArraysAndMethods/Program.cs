﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArraysAndMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] sales = new double[5];

            // we need to load the array
            GetSales(sales);

            // we need to display the array
            DisplaySales(sales);

            Console.ReadLine();

        }

        static void GetSales(double[] weeklySales)
        {
            // I used a standard for loop
            for (int weekIndex = 0; weekIndex < weeklySales.Length; weekIndex++)
            {
                Console.Write("Please enter week {0} sales: ", weekIndex + 1);
                weeklySales[weekIndex] = Convert.ToDouble(Console.ReadLine());
            }
        }

        static void DisplaySales(double[] weeklySales)
        {
            int weekIndex = 1;

            // use of a for each loop
            foreach (double weekSales in weeklySales)
            {
                Console.WriteLine("Week {0} : {1:C} sales", weekIndex, weekSales);
                weekIndex++;
            }
        }
    }
}
