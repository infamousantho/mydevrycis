﻿using System;
using System.Collections.Generic;
using System.Collections; // you need this 
using System.Linq;
using System.Text;

namespace ArrayList_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            int average;

            //fully qualified with namespaces
            //System.Collections.ArrayList scores = new System.Collections.ArrayList();

            // without namespaces because we have the using System.Collections statement at the top
            ArrayList scores = new ArrayList();

            // call get scores method passing the array list as a parameter
            // notice that I did not use ref!!! Don't you find it interesting
            // that the arraylist is populated but there is no return value
            // The reason why is object type variables such as arraylists and arrays (amongst other types)
            // are reference typed data (lookup value type versus reference type), so they are
            // always, and did I mention the word always, passed by reference regardless if you put ref or not!
            GetScores(scores);

            DisplayScores(scores);

            // this method returns an integer (the average in this case)
            average = CalculateAverage(scores);

            DisplayAverage(average);

            Console.ReadLine();

        }

        static void GetScores(ArrayList scores)
        {
            do
            {
                Console.Write("Please enter a score: ");
                scores.Add(Convert.ToInt32(Console.ReadLine()));

                Console.Write("Continue? y/n ");
            }
            while (Console.ReadLine().ToUpper() == "Y");

            scores.Sort();  // sort the arraylist
        }

        static void DisplayScores(System.Collections.ArrayList scores)
        {
            // loop through using an object based for loop
            // arraylist items are objects (anything can fit into an object)
            foreach (object score in scores)
            {
                Console.WriteLine(score.ToString());
            }
        }

        static int CalculateAverage(ArrayList scores)
        {
            int totalScores = 0;

            foreach (object score in scores)
            {
                totalScores += Convert.ToInt32(score);
            }

            return totalScores / scores.Count;
        }

        static void DisplayAverage(int average)
        {
            Console.WriteLine("The average is {0}", average);
        }

    }
}
