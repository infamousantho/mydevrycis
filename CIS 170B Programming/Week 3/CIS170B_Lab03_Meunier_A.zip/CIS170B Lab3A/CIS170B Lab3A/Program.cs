﻿// ---------------------------------------------------------------
// Programming Assignment: LAB3A
// Developer: Anthony Meunier
// Date Written: 7/27/2014
// Purpose:	DIVE Scoring Program
// ---------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS170B_Lab3A
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //declare variables
            string name, city, again;
            double degree = 0, judgeScore = 0, high = -0.01, low = 10.01, totalScore = 0;
            
            //get diver information
            do
            {
                Console.Write("Diver's name: ");
                name = Console.ReadLine();

                Console.Write("Diver's city: ");
                city = Console.ReadLine();

                Console.Write("Dive degree of difficulty: ");
                degree = Convert.ToDouble(Console.ReadLine());
                //validate degree of difficulty
                while (degree < 1.00 || degree > 1.67)
                {
                    Console.Write("Please enter a degree of difficulty between 1.00 and 1.67!: ");
                    degree = Convert.ToDouble(Console.ReadLine());
                }

                //prompt user to enter five judge's scores
                for (int i = 0; i < 5; i++)
                {
                    Console.Write("Judge #{0}: ", i + 1);
                    judgeScore = Convert.ToDouble(Console.ReadLine());

                    //validate judge's scores
                    while (judgeScore < 0 || judgeScore > 10)
                    {
                        Console.Write("Please enter a judge score between 0 and 10! ");
                        judgeScore = Convert.ToDouble(Console.ReadLine());
                    }

                    //accumulate and find total score
                    totalScore = totalScore + judgeScore;

                    //find high and low scores
                    if (judgeScore > high)
                    {
                        high = judgeScore;
                    }
                    if (judgeScore < low)
                    {
                        low = judgeScore;
                    }
                }

                //calculate and display final score
                Console.WriteLine();
                Console.WriteLine("Dive final score: {0:f2}", (totalScore - high - low) / 3 * degree);

                //check for sentinel value
                Console.WriteLine();
                Console.WriteLine("Do you want to process another dive? (Y/N)");
                again = Console.ReadLine().ToUpper();
            } while (again == "Y");

    //keep console display open
    Console.ReadLine();
        }
    }
}
